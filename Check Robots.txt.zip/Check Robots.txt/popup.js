// popup.js

document.addEventListener('DOMContentLoaded', function () {
  // Lấy domain từ tab hiện tại
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    const url = new URL(tabs[0].url);
    const domain = url.hostname;

    // Gửi yêu cầu kiểm tra Robots.txt
    fetch(`https://${domain}/robots.txt`)
      .then(response => {
        if (response.status === 200) {
          return response.text();
        } else {
          throw new Error(`Error loading Robots.txt for ${domain}.`);
        }
      })
      .then(robotsTxt => {
        // Hiển thị nội dung của Robots.txt trong popup
        document.getElementById('result').innerText = robotsTxt;
      })
      .catch(error => {
        document.getElementById('result').innerText = error.message;
      });
  });
});
